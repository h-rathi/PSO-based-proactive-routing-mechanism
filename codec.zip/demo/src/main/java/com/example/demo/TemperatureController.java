package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TemperatureController {

    @Autowired
    private TemperatureService temperatureService;

    @RequestMapping("/insertTemperature/{temperature}")
    public String insertTemperature(@PathVariable String temperature) {
        temperatureService.insertTemperature(temperature);
        return "Temperature inserted successfully";
    }
}
