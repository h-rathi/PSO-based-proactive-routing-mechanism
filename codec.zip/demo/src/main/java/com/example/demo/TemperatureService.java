package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.stereotype.Service;

@Service
public class TemperatureService {

    public void insertTemperature(String temperature) {
        String serverName = "localhost:3307";
        String userName = "root";
        String password = "root";
        String databaseName = "nu";

        try {
            // Create MySQL connection from Java to MySQL server
            Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://" + serverName + "/" + databaseName,
                    userName,
                    password
            );

            // Prepare the SQL statement
            String sql = "INSERT INTO temp (tem) VALUES (?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, temperature);

            // Execute the SQL statement
            preparedStatement.executeUpdate();

            System.out.println("New record created successfully");

            // Close resources
            preparedStatement.close();
            connection.close();

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
