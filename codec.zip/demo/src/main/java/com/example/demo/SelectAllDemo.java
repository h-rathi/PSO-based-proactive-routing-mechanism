package com.example.demo;
import java.sql.*;
import java.util.Scanner;

public class SelectAllDemo {
public static void main(String[] args) {
	
	
	try{
		//Class.forName("com.mysql.cj.jdbc.Driver"); 
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3307/nu","root","root"); 
		Statement stmt=con.createStatement();
		String sql="Select * from temp ";
		System.out.println(sql);
		ResultSet rs=stmt.executeQuery(sql);
		while(rs.next())
			System.out.println(rs.getString(1));
		System.out.println("Record displayed");
	}
	catch (Exception e){
		e.printStackTrace();
	}
}
}
